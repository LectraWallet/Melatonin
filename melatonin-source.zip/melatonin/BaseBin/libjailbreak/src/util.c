#include "util.h"
#include "primitives.h"
#include "info.h"
#include "kernel.h"
#include "translation.h"
#include <spawn.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <signal.h>
#include <dlfcn.h>
#include <sys/sysctl.h>
#include <archive.h>
#include <archive_entry.h>
#include <math.h>
#include <mach-o/dyld.h>
#include <dirent.h>
#include <IOKit/IOKitLib.h>
#include <mach-o/dyld_images.h>
#include <mach-o/getsect.h>
#include <dyld_cache_format.h>
#include <sys/param.h>
#include <sys/mount.h>
#include <stdatomic.h>
#include <errno.h>
extern char **environ;

#define FAKE_PHYSPAGE_TO_MAP 0x13370000

int posix_spawnattr_set_registered_ports_np(posix_spawnattr_t * __restrict attr, mach_port_t portarray[], uint32_t count);

const struct mach_header *get_mach_header(const char *name)
{
	const struct mach_header *mh = NULL;
	for (int i = 0; i < _dyld_image_count(); i++) {
		if (!strcmp(_dyld_get_image_name(i), name)) {
			mh = _dyld_get_image_header(i);
			break;
		}
	}
	return mh;
}

uintptr_t get_mach_vmaddr_slide(const char *name)
{
	uintptr_t slide = 0;
	for (int i = 0; i < _dyld_image_count(); i++) {
		if (!strcmp(_dyld_get_image_name(i), name)) {
			slide = _dyld_get_image_vmaddr_slide(i);
			break;
		}
	}
	return slide;
}

bool host_is_arm64e(void)
{
	static cpu_type_t hostCpuType;
	static cpu_subtype_t hostCpuSubtype;
	static dispatch_once_t onceToken = 0;
	dispatch_once(&onceToken, ^{
		size_t len;
		// Query for cputype
		len = sizeof(hostCpuType);
		if (sysctlbyname("hw.cputype", &hostCpuType, &len, NULL, 0) == -1) { printf("Error: no cputype.\n"); }
		// Query for cpusubtype
		len = sizeof(hostCpuSubtype);
		if (sysctlbyname("hw.cpusubtype", &hostCpuSubtype, &len, NULL, 0) == -1) { printf("Error: no cpusubtype.\n"); }
	});

	return (hostCpuType == CPU_TYPE_ARM64) && ((hostCpuSubtype & ~0xff000000) == CPU_SUBTYPE_ARM64E);
}

void proc_iterate(void (^itBlock)(uint64_t, bool*))
{
	uint64_t proc = ksymbol(allproc);
	while((proc = kread_ptr(proc + koffsetof(proc, list_next))))
	{
		bool stop = false;
		itBlock(proc, &stop);
		if(stop) return;
	}
}

uint64_t proc_self(void)
{
	static uint64_t gSelfProc = 0;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		gSelfProc = proc_find(getpid());
		// decrement ref count again, we assume proc_self will exist for the whole lifetime of this process
		proc_rele(gSelfProc);
	});
	return gSelfProc;
}

uint64_t task_self(void)
{
	static uint64_t gSelfTask = 0;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		gSelfTask = proc_task(proc_self());
	});
	return gSelfTask;
}

uint64_t vm_map_self(void)
{
	static uint64_t gSelfMap = 0;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		gSelfMap = kread_ptr(task_self() + koffsetof(task, map));
	});
	return gSelfMap;
}

uint64_t pmap_self(void)
{
	static uint64_t gSelfPmap = 0;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		gSelfPmap = kread_ptr(vm_map_self() + koffsetof(vm_map, pmap));
	});
	return gSelfPmap;
}

uint64_t ttep_self(void)
{
	static uint64_t gSelfTTEP = 0;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		gSelfTTEP = kread64(pmap_self() + koffsetof(pmap, ttep));
	});
	return gSelfTTEP;
}

uint64_t tte_self(void)
{
	static uint64_t gSelfTTE = 0;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		gSelfTTE = kread_ptr(pmap_self() + koffsetof(pmap, tte));
	});
	return gSelfTTE;
}

uint64_t task_get_ipc_port_table_entry(uint64_t task, mach_port_t port)
{
	uint64_t itk_space = kread_ptr(task + koffsetof(task, itk_space));
	return ipc_entry_lookup(itk_space, port);
}

uint64_t task_get_ipc_port_object(uint64_t task, mach_port_t port)
{
	return kread_ptr(task_get_ipc_port_table_entry(task, port) + koffsetof(ipc_entry, object));
}

uint64_t task_get_ipc_port_kobject(uint64_t task, mach_port_t port)
{
	return kread_ptr(task_get_ipc_port_object(task, port) + koffsetof(ipc_port, kobject));
}

uint32_t sptm_frame_get_refcnt_off(uint64_t frame)
{
	uint8_t typeIdx = kread8(frame + koffsetof(sptm_frame, type));
	uint32_t refcnt_off = 0;

	if (ksymbol(libsptm_frame_type_params)) {
		uint64_t typeDescriptor = kread64(ksymbol(libsptm_frame_type_params)) + (ksizeof(sptm_frame_type_descriptor) * typeIdx);
		uint8_t type = kread8(typeDescriptor + koffsetof(sptm_frame_type_descriptor, type));
		
		if (type == 1) {
			refcnt_off = koffsetof(sptm_frame, nested_refcnt);
		}
		else if (type == 2) {
			refcnt_off = koffsetof(sptm_frame, mapping_refcnt);
		}
		else {
			printf("WARNING: Hit unknown refcnt type (%d) from index %d on frame %#llx (nested_refcnt: %u, mapping_refcnt: %u)\n", type, typeIdx, frame, kread16(frame + koffsetof(sptm_frame, nested_refcnt)), kread16(frame + koffsetof(sptm_frame, mapping_refcnt)));
		}
	}
	else {
		if (typeIdx == 8 || typeIdx == 17 || typeIdx == 18 || typeIdx == 31) {
			refcnt_off = koffsetof(sptm_frame, nested_refcnt);
		}
		else if (typeIdx == 9 || typeIdx == 19 || typeIdx == 20 || typeIdx == 32) {
			refcnt_off = koffsetof(sptm_frame, mapping_refcnt);
		}
		else {
			printf("WARNING: Hit unknown refcnt type index (%d) on frame %#llx (nested_refcnt: %u, mapping_refcnt: %u)\n", typeIdx, frame, kread16(frame + koffsetof(sptm_frame, nested_refcnt)), kread16(frame + koffsetof(sptm_frame, mapping_refcnt)));
		}
	}

	return refcnt_off;
}

uint16_t pagetable_get_refcnt(uint64_t pt_pa)
{
	if (ksymbol(libsptm_frame_table)) {
		uint64_t sptmFrame = pa_to_sptm_frame(pt_pa);
		uint64_t refcntOff = sptm_frame_get_refcnt_off(sptmFrame);
		if (!refcntOff) return 0;
		return kread16(sptmFrame + refcntOff);
	}
	else {
		uint64_t pvh = pai_to_pvh(pa_index(pt_pa));
		uint64_t ptdp = pvh_ptd(pvh);
		uint64_t pinfo = kread64(ptdp + koffsetof(pt_desc, ptd_info));
		return kread16(pinfo + 0x0);
	}
}

void pagetable_set_refcnt(uint64_t pt_pa, uint16_t refcnt)
{
	if (ksymbol(libsptm_frame_table)) {
		uint64_t sptmFrame = pa_to_sptm_frame(pt_pa);
		uint64_t refcntOff = sptm_frame_get_refcnt_off(sptmFrame);
		if (!refcntOff) return;
		physwrite16(kvtophys(sptmFrame + refcntOff), refcnt);
	}
	else {
		uint64_t pvh = pai_to_pvh(pa_index(pt_pa));
		uint64_t ptdp = pvh_ptd(pvh);
		uint64_t pinfo = kread64(ptdp + koffsetof(pt_desc, ptd_info));
		physwrite16(kvtophys(pinfo + 0x0), refcnt);
	}
}

void pagetable_modify_refcount(uint64_t pt_pa, int32_t delta)
{
	if (delta == 0) return;

	uint64_t refcntPtr = 0;

	if (ksymbol(libsptm_frame_table)) {
		uint64_t sptmFrame = pa_to_sptm_frame(pt_pa);
		uint64_t refcntOff = sptm_frame_get_refcnt_off(sptmFrame);
		if (!refcntOff) return;
		refcntPtr = kvtophys(sptmFrame + refcntOff);
	}
	else {
		uint64_t pvh = pai_to_pvh(pa_index(pt_pa));
		uint64_t ptdp = pvh_ptd(pvh);
		uint64_t pinfo = kread64(ptdp + koffsetof(pt_desc, ptd_info));
		refcntPtr = kvtophys(pinfo + 0x0);
	}

	if (gPrimitives.physaccess_mapped) {
		physaccess_mapped(refcntPtr, sizeof(uint16_t), ^(void *ptr){
			_Atomic(uint16_t) *uintPtr = ptr;
			if (delta > 0) {
				atomic_fetch_add(uintPtr, delta);
			}
			else if (delta < 0) {
				atomic_fetch_sub(uintPtr, -delta);
			}
		});
	}
	else {
		physwrite16(refcntPtr, physread16(refcntPtr) + delta);
	}
}

void pagetable_set_pmap(uint64_t pt_pa, uint64_t pmap)
{
	uint64_t pvh = pai_to_pvh(pa_index(pt_pa));
	uint64_t ptdp = pvh_ptd(pvh);
	uint64_t ptdp_pa = kvtophys(ptdp);

	physwrite64(ptdp_pa + koffsetof(pt_desc, pmap), pmap);
}

void pagetable_set_vas(uint64_t pt_pa, uint64_t va_start)
{
	uint64_t pvh = pai_to_pvh(pa_index(pt_pa));
	uint64_t ptdp = pvh_ptd(pvh);
	uint64_t ptdp_pa = kvtophys(ptdp);

	// On A14+ PT_INDEX_MAX is 4, for whatever reason
	// However in practice, only the first slot is used...
	for (uint64_t po = 0; po < vm_page_size; po += vm_real_kernel_page_size) {
		physwrite64(ptdp_pa + koffsetof(pt_desc, va) + (po / vm_page_size), va_start + po);
	}
}

void pagetable_set_level(uint64_t pt_pa, uint8_t level)
{
	if (ksymbol(libsptm_frame_table)) {
		uint64_t sptmFrame = pa_to_sptm_frame(pt_pa);
		physwrite8(kvtophys(sptmFrame + koffsetof(sptm_frame, level)), level);
	}
}

#define L2_ROUND_DOWN(x) (((vm_address_t)(x)) & (~(L2_BLOCK_SIZE-1)))
#define L2_ROUND_UP(x) ( (((vm_address_t)(x)) + L2_BLOCK_SIZE-1)  & (~(L2_BLOCK_SIZE-1)) ) 

void *allocate_page_table_range(void)
{
	task_vm_info_data_t data = {};
	task_info_t info = (task_info_t)(&data);
	mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
	task_info(mach_task_self(), TASK_VM_INFO, info, &count);

	for (vm_address_t curBlock = L2_ROUND_UP(data.min_address); curBlock < L2_ROUND_DOWN(data.max_address); curBlock += L2_BLOCK_SIZE) {
		vm_address_t thisAllocation = curBlock;
		if (vm_allocate(mach_task_self(), &thisAllocation, L2_BLOCK_SIZE, VM_FLAGS_FIXED) == KERN_SUCCESS) {
			return (void *)thisAllocation;
		}
	}

	return NULL;
}

void free_page_table_range(void *start)
{
	vm_address_t vmaddr = (vm_address_t)start;
	vm_deallocate(mach_task_self(), vmaddr, L2_BLOCK_SIZE);
}

uint64_t alloc_page_table_unassigned(void)
{
	uint64_t pmap = pmap_self();
	uint64_t ttep = kread64(pmap + koffsetof(pmap, ttep));

	void *free_lvl2 = NULL;
	uint64_t ttep_lvl2 = 0;
	uint64_t allocatedPT = 0;
	while (true) {
		// When we allocate the entire address range of an L2 block, we can assume ownership of the backing table
		free_lvl2 = allocate_page_table_range();
		if (free_lvl2 == NULL) {
			printf("WARNING: Failed to allocate L2 page table address range\n");
			return 0;
		}
		// Now, fault in one page to make the kernel allocate the page table for it
		mlock((void *)free_lvl2, 0x4000);
	
		// Find the newly allocated page table
		uint64_t lvl = PMAP_TT_L2_LEVEL;
		allocatedPT = vtophys_lvl(ttep, (uint64_t)free_lvl2, &lvl, &ttep_lvl2);

		uint16_t refcnt = pagetable_get_refcnt(allocatedPT);
		if (refcnt != 1) {
			// Something is off, retry
			munlock((void *)free_lvl2, 0x4000);
			free_page_table_range(free_lvl2);
			continue;
		}
		break;
	}

	// Handle case where all entries in the level 2 table are 0 after we leak ours
	// In that case, leak an allocation in the span of it to keep it alive
	/*uint64_t lvl2Table = tte_lvl2 & ~PAGE_MASK;
	uint64_t lvl2TableEntries[PAGE_SIZE / sizeof(uint64_t)];
	physreadbuf(lvl2Table, lvl2TableEntries, PAGE_SIZE);
	int freeIdx = -1;
	for (int i = 0; i < (PAGE_SIZE / sizeof(uint64_t)); i++) {
		uint64_t curPtr = lvl2Table + (sizeof(uint64_t) * i);
		if (curPtr != tte_lvl2) {
			if (lvl2TableEntries[i]) {
				freeIdx = -1;
				break;
			}
			else {
				freeIdx = i;
			}
		}
	}
	if (freeIdx != -1) {
		vm_address_t freeUserspace = ((uint64_t)free_lvl2 & ~L1_BLOCK_MASK) + (freeIdx * L2_BLOCK_SIZE);
		if (vm_allocate(mach_task_self(), &freeUserspace, 0x4000, VM_FLAGS_FIXED) == 0) {
			*(volatile uint8_t *)freeUserspace;
		}
	}*/

	// Bump reference count of our allocated page table
	pagetable_set_refcnt(allocatedPT, 0x1337);

	// Deallocate address range (our allocated page table will stay because we bumped it's reference count)
	munlock((void *)free_lvl2, 0x4000);
	free_page_table_range(free_lvl2);

	// Remove our allocated page table from it's original location (leak it)
	physwrite64(ttep_lvl2, 0);

	// Ensure there is at least one entry in page table
	// Attempts to prevent "pte is empty" panic
	// Sometimes weird prefetches happen so this has to be a valid physical page to ensure those don't panic
	// Disabled for now cause it causes super weird issues
	//physwrite64(allocatedPT, kconstant(physBase) | PERM_TO_PTE(PERM_KRW_URW) | PTE_NON_GLOBAL | PTE_OUTER_SHAREABLE | PTE_LEVEL3_ENTRY);

	// Reference count of new page table must be 0!
	// original ref count is 1 because the table holds one PTE
	// Our new PTEs are not part of the pmap layer though so refcount needs to be 0
	pagetable_set_refcnt(allocatedPT, 0);

	if (ksymbol(libsptm_frame_table)) {
		// On SPTM, the refcount of the parent has to be decremented aswell
		pagetable_modify_refcount(ttep_lvl2, -1);
	}

	// After we leaked the page table, the ledger still thinks it belongs to our process
	// We need to remove it from there aswell so that the process doesn't get jetsam killed
	// (This ended up more complicated than I thought, so I just disabled jetsam in launchd)
	//uint64_t ledger = kread_ptr(pmap + koffsetof(pmap, ledger));
	//uint64_t ledger_pa = kvtophys(ledger);
	//int page_table_ledger = physread32(ledger_pa + koffsetof(_task_ledger_indices, page_table));
	//physwrite32(ledger_pa + koffsetof(_task_ledger_indices, page_table), page_table_ledger - 1);

	return allocatedPT;
}

uint64_t pmap_alloc_page_table(uint64_t pmap, uint8_t level, uint64_t va_start)
{
	if (!pmap) {
		pmap = pmap_self();
	}

	uint64_t pt_pa = alloc_page_table_unassigned();
	if (!pt_pa) return 0;

	// At this point the allocated page table is associated to the pmap of this process and the virtual address it was allocated on
	// On SPTM devices, the page table is also associated to the level it was previously used for
	// We now need to replace this info with the correct context in which it will be used
	pagetable_set_pmap(pt_pa, pmap);
	pagetable_set_vas(pt_pa, va_start);
	pagetable_set_level(pt_pa, level);

	return pt_pa;
}

int pmap_expand_range(uint64_t pmap, uint64_t vaStart, uint64_t size)
{
	uint64_t ttep = kread64(pmap + koffsetof(pmap, ttep));

	if (is_kcall_available()) {
		uint64_t unmappedStart = 0, unmappedSize = 0;

		uint64_t l2Start = vaStart & ~L2_BLOCK_MASK;
		uint64_t l2End = (vaStart + (size - 1)) & ~L2_BLOCK_MASK;
		uint64_t l2Count = ((l2End - l2Start) / L2_BLOCK_SIZE) + 1;

		for (uint64_t i = 0; i <= l2Count; i++) {
			uint64_t curL2 = l2Start + (i * L2_BLOCK_SIZE);

			uint64_t leafLevel = PMAP_TT_L3_LEVEL;
			uint64_t pt3 = 0;
			vtophys_lvl(ttep, curL2, &leafLevel, &pt3);
			if (leafLevel == PMAP_TT_L3_LEVEL || i == l2Count) {
				// i == l2Count: one extra cycle that this for loop takes
				// We hit this block either if there was a mapping or at the end
				// Alloc page tables for the current area (unmappedStart, unmappedSize) by running pmap_enter_options on every page
				// And then running pmap_remove on the entire area while nested is true

				for (uint64_t l2Off = 0; l2Off < unmappedSize; l2Off += L2_BLOCK_SIZE) {
					kern_return_t kr = pmap_enter_options_addr(pmap, FAKE_PHYSPAGE_TO_MAP, unmappedStart + l2Off);
					if (kr != KERN_SUCCESS) {
						return -7;
					}
				}

				// Set type to nested
				physwrite8(kvtophys(pmap + koffsetof(pmap, type)), 3);

				// Remove mapping (table will stay cause nested is set)
				pmap_remove(pmap, unmappedStart, unmappedStart + unmappedSize);

				// Change type back
				physwrite8(kvtophys(pmap + koffsetof(pmap, type)), 0);
				
				unmappedStart = 0;
				unmappedSize = 0;
				continue;
			}
			else {
				if (unmappedStart == 0) {
					unmappedStart = curL2;
				}
				unmappedSize += L2_BLOCK_SIZE;
			}
		}
	}
	else {
		uint64_t l2Start = (vaStart & ~L2_BLOCK_MASK);
		uint64_t l2End   = (((vaStart + size) + (L2_BLOCK_SIZE-1)) & ~L2_BLOCK_MASK);
		for (uint64_t va = l2Start; va < l2End; va += L2_BLOCK_SIZE) {
			uint64_t leafLevel;
			do {
				leafLevel = PMAP_TT_L3_LEVEL;
				uint64_t pte = 0;
				vtophys_lvl(ttep, va, &leafLevel, &pte);
				if (leafLevel != PMAP_TT_L3_LEVEL) {
					uint64_t pt_va = 0;
					switch (leafLevel) {
						case PMAP_TT_L1_LEVEL: {
							pt_va = va & ~L1_BLOCK_MASK;
							break;
						}
						case PMAP_TT_L2_LEVEL: {
							pt_va = va & ~L2_BLOCK_MASK;
							break;
						}
					}
					leafLevel++;
					uint64_t newTable = pmap_alloc_page_table(pmap, leafLevel, pt_va);
					if (newTable) {
						uint64_t oldEntry = physread64(pte);
						physwrite64(pte, newTable | ARM_TTE_VALID | ARM_TTE_TYPE_TABLE);
						if (ksymbol(libsptm_frame_table) && !oldEntry) {
							// On SPTM, we need to bump the refcount of the parent page table aswell
							uint64_t parentPt = 0;
							uint64_t parentLevel = leafLevel - 1;

							if (parentLevel == 1) {
								// The level 1 page table can either be 0x4000 in size (iOS 17-18) or 0x40 in size (iOS 26+)
								// To make sure this is always right, we just take it directly from ttep
								parentPt = ttep;
							}
							else {
								parentPt = pte & ~PAGE_MASK;
							}

							pagetable_modify_refcount(parentPt, 1);
						}
					}
					else {
						return -2;
					}
				}
			} while (leafLevel < PMAP_TT_L3_LEVEL);
		}
	}
	return 0;
}

int pmap_map_in_with_flags(uint64_t pmap, uint64_t uaStart, uint64_t paStart, uint64_t size, uint64_t flags)
{
	uint64_t ttep = kread64(pmap + koffsetof(pmap, ttep));

	uint64_t paEnd = paStart + size;
	uint64_t uaEnd = uaStart + size;

	uint64_t uaL2Start = uaStart & ~L2_BLOCK_MASK;
	uint64_t uaL2End   = ((uaStart + size - 1) + L2_BLOCK_SIZE) & ~L2_BLOCK_MASK;

	uint64_t paL2Start = paStart & ~L2_BLOCK_MASK;
	uint64_t l2Count = (((uaL2End - uaL2Start) - 1) / L2_BLOCK_SIZE) + 1;

	// Sanity check: Ensure the entire area to be mapped in is not mapped to anything yet
	for(uint64_t ua = uaStart; ua < uaEnd; ua += vm_real_kernel_page_size) {
		uint64_t leafLevel = PMAP_TT_L3_LEVEL;
		if (vtophys_lvl(ttep, ua, &leafLevel, NULL) != 0) {
			return -1;
		}
		else {
			// Performance improvement
			// If there is no L1 / L2 mapping we can skip a whole bunch of addresses
			if (leafLevel == PMAP_TT_L1_LEVEL) {
				ua = (((ua + L1_BLOCK_SIZE) & ~L1_BLOCK_MASK) - vm_real_kernel_page_size);
			}
			else if (leafLevel == PMAP_TT_L2_LEVEL) {
				ua = (((ua + L2_BLOCK_SIZE) & ~L2_BLOCK_MASK) - vm_real_kernel_page_size);
			}
		}

		if (vtophys(ttep, ua)) return -2;
		// TODO: If all mappings match 1:1, maybe return 0 instead?
	}

	// Allocate all page tables that need to be allocated
	if (pmap_expand_range(pmap, uaStart, size) != 0) return -3;

	// Insert entries into L3 pages
	uint64_t curPA = paStart;
	for (uint64_t i = 0; i < l2Count; i++) {
		uint64_t uaL2Cur = uaL2Start + (i * L2_BLOCK_SIZE);

		// Current L2 range
		uint64_t uaL2CurStart = uaL2Cur;
		uint64_t uaL2CurEnd = uaL2Cur + L2_BLOCK_SIZE;

		// Round to passed boundary if neccessary
		if (uaStart > uaL2CurStart) uaL2CurStart = uaStart;
		if (uaEnd < uaL2CurEnd) uaL2CurEnd = uaEnd;

		// Create full table for this mapping
		uint64_t tableToWrite[L2_BLOCK_COUNT];
		memset(tableToWrite, 0, sizeof(tableToWrite));
		for (uint64_t curUA = uaL2CurStart; curUA < uaL2CurEnd; curUA += vm_real_kernel_page_size, curPA += vm_real_kernel_page_size) {
			int idx = (curUA - uaL2Cur) / vm_real_kernel_page_size;
			tableToWrite[idx] = curPA | flags;
		}

		// Replace table with the entries we generated
		uint64_t leafLevel = PMAP_TT_L2_LEVEL;
		uint64_t level2Table = vtophys_lvl(ttep, uaL2Cur, &leafLevel, NULL);
		if (!level2Table) return -4;
		physwritebuf(level2Table, tableToWrite, vm_real_kernel_page_size);
	}

	return 0;
}

int pmap_map_in(uint64_t pmap, uint64_t uaStart, uint64_t paStart, uint64_t size)
{
	return pmap_map_in_with_flags(pmap, uaStart, paStart, size, PERM_TO_PTE(PERM_KRW_URW) | PTE_NON_GLOBAL | PTE_OUTER_SHAREABLE | PTE_LEVEL3_ENTRY);	
}

uint64_t pmap_find_main_binary_code_dir(uint64_t pmap)
{
	if (!host_is_arm64e()) return -1;

	uint64_t mainCodeDir = 0;
	uint64_t pmap_cs_region = kread_ptr(pmap + koffsetof(pmap, pmap_cs_main));
	while (pmap_cs_region && !mainCodeDir) {
		uint64_t pmap_cs_code_dir = kread_ptr(pmap_cs_region + koffsetof(pmap_cs_region, cd_entry));
		while (pmap_cs_code_dir) {
			_Bool mainBinary = kread64(pmap_cs_code_dir + koffsetof(pmap_cs_code_directory, main_binary));
			if (mainBinary) {
				mainCodeDir = pmap_cs_code_dir;
				break;
			}
			pmap_cs_code_dir = kread_ptr(pmap_cs_code_dir + koffsetof(pmap_cs_code_directory, pmap_cs_code_directory_next));
		}
		pmap_cs_region = kread_ptr(pmap_cs_region + koffsetof(pmap_cs_region, pmap_cs_region_next));
	}
	return mainCodeDir;
}

uint64_t proc_find_main_binary_code_dir(uint64_t proc)
{
	if (!host_is_arm64e()) return -1;

	uint64_t task = proc_task(proc);
	uint64_t map = kread_ptr(task + koffsetof(task, map));
	uint64_t pmap = kread_ptr(map + koffsetof(vm_map, pmap));
	return pmap_find_main_binary_code_dir(pmap);
}

uint32_t pmap_cs_trust_string_to_int(const char *trustString)
{
	if (!host_is_arm64e()) return -1;

	int trustInt = 0;
	if (__builtin_available(iOS 16.0, *)) {
		if      (!strcmp(trustString, "PMAP_CS_UNTRUSTED"))             trustInt = 0;
		else if (!strcmp(trustString, "PMAP_CS_RETIRED"))               trustInt = 1;
		else if (!strcmp(trustString, "PMAP_CS_PROFILE_PREFLIGHT"))     trustInt = 2;
		else if (!strcmp(trustString, "PMAP_CS_COMPILATION_SERVICE"))   trustInt = 3;
		else if (!strcmp(trustString, "PMAP_CS_OOP_JIT"))               trustInt = 4;
		else if (!strcmp(trustString, "PMAP_CS_LOCAL_SIGNING"))         trustInt = 5;
		else if (!strcmp(trustString, "PMAP_CS_PROFILE_VALIDATED"))     trustInt = 6;
		else if (!strcmp(trustString, "PMAP_CS_APP_STORE"))             trustInt = 7;
		else if (!strcmp(trustString, "PMAP_CS_IN_LOADED_TRUST_CACHE")) trustInt = 8;
		else if (!strcmp(trustString, "PMAP_CS_IN_STATIC_TRUST_CACHE")) trustInt = 9;
	}
	else {
		if      (!strcmp(trustString, "PMAP_CS_UNTRUSTED"))             trustInt = 0;
		else if (!strcmp(trustString, "PMAP_CS_RETIRED"))               trustInt = 1;
		else if (!strcmp(trustString, "PMAP_CS_PROFILE_PREFLIGHT"))     trustInt = 2;
		else if (!strcmp(trustString, "PMAP_CS_COMPILATION_SERVICE"))   trustInt = 3;
		else if (!strcmp(trustString, "PMAP_CS_LOCAL_SIGNING"))         trustInt = 4;
		else if (!strcmp(trustString, "PMAP_CS_PROFILE_VALIDATED"))     trustInt = 5;
		else if (!strcmp(trustString, "PMAP_CS_APP_STORE"))             trustInt = 6;
		else if (!strcmp(trustString, "PMAP_CS_IN_LOADED_TRUST_CACHE")) trustInt = 7;
		else if (!strcmp(trustString, "PMAP_CS_IN_STATIC_TRUST_CACHE")) trustInt = 8;
	}
	return trustInt;
}

int sign_kernel_thread(uint64_t proc, mach_port_t threadPort)
{
	uint64_t threadKobj = task_get_ipc_port_kobject(proc_task(proc), threadPort);
	uint64_t threadContext = kread_ptr(threadKobj + koffsetof(thread, machine_contextData));

	uint64_t pc   = kread64(threadContext + offsetof(kRegisterState, pc));
	uint64_t cpsr = kread64(threadContext + offsetof(kRegisterState, cpsr));
	uint64_t lr   = kread64(threadContext + offsetof(kRegisterState, lr));
	uint64_t x16  = kread64(threadContext + offsetof(kRegisterState, x[16]));
	uint64_t x17  = kread64(threadContext + offsetof(kRegisterState, x[17]));

	return kcall(NULL, ksymbol(ml_sign_thread_state), 6, (uint64_t[]){ threadContext, pc, cpsr, lr, x16, x17 });
}

uint64_t kpacda(uint64_t pointer, uint64_t modifier)
{
	if (gPrimitives.kexec && kgadget(pacda)) {
		// |------- GADGET -------|
		// | cmp x1, #0		      |
		// | pacda x1, x9         |
		// | str x9, [x8]         |
		// | csel x9, xzr, x1, eq |
		// | ret                  |
		// |----------------------|
		uint64_t output = 0;
		uint64_t output_kernelVA = phystokv(vtophys(kread_ptr(pmap_self() + koffsetof(pmap, ttep)), (uint64_t)&output));
		kRegisterState threadState = { 0 };
		threadState.pc = kgadget(pacda);
		threadState.x[1] = pointer;
		threadState.x[9] = modifier;
		threadState.x[8] = output_kernelVA;
		kexec(&threadState);
		return output;
	}
	return 0;
}

uint64_t kptr_sign(uint64_t kaddr, uint64_t pointer, uint16_t salt)
{
	uint64_t modifier = (kaddr & 0xffffffffffff) | ((uint64_t)salt << 48);
	return kpacda(UNSIGN_PTR(pointer), modifier);
}

int kwrite1_bits(uint64_t startPtr, uint32_t bitCount)
{
	uint32_t byteSize = ceil((float)bitCount / 8);
	uint8_t buf[byteSize];

	for (uint32_t i = 0; i < bitCount; i += 8) {
		uint32_t rem = (bitCount - i);
		if (rem < 8) {
			for (int y = 0; y < rem; y++) {
				buf[i/8] |= (1 << y);
			}
		}
		else {
			buf[i/8] = 0xff;
		}
	}

	return kwritebuf(startPtr, buf, byteSize);
}

void proc_allow_all_syscalls(uint64_t proc)
{
	if (!gSystemInfo.kernelStruct.proc_ro.exists) return;
	uint64_t proc_ro = kread_ptr(proc + koffsetof(proc, proc_ro));

	uint64_t bsdFilter = kread_ptr(proc_ro + koffsetof(proc_ro, syscall_filter_mask));
	uint64_t machFilter = kread_ptr(proc_ro + koffsetof(proc_ro, mach_trap_filter_mask));
	uint64_t machKobjFilter = kread_ptr(proc_ro + koffsetof(proc_ro, mach_kobj_filter_mask));

	if (bsdFilter) {
		kwrite1_bits(bsdFilter, kconstant(nsysent));
	}
	if (machFilter) {
		kwrite1_bits(machFilter, kconstant(mach_trap_count));
	}
	if (machKobjFilter) {
		kwrite1_bits(machKobjFilter, kread64(ksymbol(mach_kobj_count)));
	}
}

void proc_remove_msg_filter(uint64_t proc)
{
	if (__builtin_available(iOS 16.0, *)) {
		#define TFRO_FILTER_MSG                 0x00004000

		if (koffsetof(proc_ro, t_flags_ro)) {
			// iOS 16.1+
			uint64_t proc_ro = kread_ptr(proc + koffsetof(proc, proc_ro));
			uint32_t t_flags = kread32(proc_ro + koffsetof(proc_ro, t_flags_ro));
			kwrite32(proc_ro + koffsetof(proc_ro, t_flags_ro), t_flags & ~TFRO_FILTER_MSG);
		}
		else if (koffsetof(task, flags)) {
			// iOS 16.0.x
			uint64_t task = proc_task(proc);
			uint32_t t_flags = kread32(task + koffsetof(task, flags));
			kwrite32(task + koffsetof(task, flags), t_flags & ~TFRO_FILTER_MSG);
		}
	}
}

uint64_t proc_get_vnode_for_fd(uint64_t proc, int fd)
{
	uint64_t ofiles = kread_ptr(proc + koffsetof(proc, fd) + koffsetof(filedesc, ofiles_start));
	uint64_t fileproc = kread_ptr(ofiles + (fd * sizeof(void *)));
	uint64_t fileglob = kread_ptr(fileproc + koffsetof(fileproc, glob));
	return kread_ptr(fileglob + koffsetof(fileglob, data));
}

int fd_attach_signature(int fd, fsignatures_t *signature)
{
	off_t origPos = lseek(fd, 0, SEEK_CUR);

	// Read header, we need it later for the cputype and cpusubtype
	struct mach_header header;
	lseek(fd, signature->fs_file_start, SEEK_SET);
	if (read(fd, &header, sizeof(header)) != sizeof(header)) return -2;

	// Attach signature, since this is a binary it requires the fixup below
	// (For libraries this works without any fix up, since this is how dyld attaches them normally)
	lseek(fd, 0, SEEK_SET);
	int r = fcntl(fd, F_ADDSIGS, signature);
	lseek(fd, origPos, SEEK_SET);
	if (r != 0) return r;

	// Find cs_blob of the signature that we just attached
	uint64_t vnode = proc_get_vnode_for_fd(proc_self(), fd);
	uint64_t ubc_info = kread_ptr(vnode + koffsetof(vnode, un));
	uint64_t cs_blob = kread_ptr(ubc_info + koffsetof(ubc_info, cs_blobs));
	uint64_t target_cs_blob = 0;
	if (cs_blob) {
		do {
			uint64_t base_offset = kread64(cs_blob + koffsetof(cs_blob, base_offset));
			if (signature->fs_file_start == base_offset) {
				target_cs_blob = cs_blob;
				break;
			}
		} while (((cs_blob = kread_ptr(cs_blob + koffsetof(cs_blob, next))) != 0));
	}

	if (!target_cs_blob) return -4;

	// By default signatures attached via fcntl have cpu_type=-1, cpu_subtype=-1
	// In order to make the binary actually execute, we need to set them to the right values ourselves
	kwrite32(target_cs_blob + koffsetof(cs_blob, cpu_type), header.cputype);
	kwrite32(target_cs_blob + koffsetof(cs_blob, cpu_subtype), header.cpusubtype);
	return 0;
}

int cmd_wait_for_exit(pid_t pid)
{
	int status = 0;
	do {
		if (waitpid(pid, &status, 0) == -1) {
			return -1;
		}
	} while (!WIFEXITED(status) && !WIFSIGNALED(status));
	return status;
}

int __exec_cmd_internal_va(bool suspended, bool root, bool waitForExit, pid_t *pidOut, const char *binary, int argc, va_list va_args, char **envp)
{
	const char *argv[argc+1];
	argv[0] = binary;
	for (int i = 1; i < argc; i++) {
		argv[i] = va_arg(va_args, const char *);
	}
	argv[argc] = NULL;

	posix_spawnattr_t attr = NULL;
	posix_spawnattr_init(&attr);
	if (suspended) {
		posix_spawnattr_setflags(&attr, POSIX_SPAWN_START_SUSPENDED);
	}
	if (root) {
		posix_spawnattr_set_persona_np(&attr, 99, POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE);
		posix_spawnattr_set_persona_uid_np(&attr, 0);
		posix_spawnattr_set_persona_gid_np(&attr, 0);
	}

	char **envToUse = envp;
	if (!envToUse && getpid() != 1) {
		// We NEVER want to pass launchd's environment to any process whatsoever
		// This is because, amongst other things, it has DYLD_INSERT_LIBRARIES set to launchdhook which is NO good
		envToUse = environ;
	}

	pid_t spawnedPid = 0;
	int spawnError = posix_spawn(&spawnedPid, binary, NULL, &attr, (char *const *)argv, envToUse);
	if (attr) posix_spawnattr_destroy(&attr);
	if (spawnError != 0) return spawnError;

	if (waitForExit && !suspended) {
		return cmd_wait_for_exit(spawnedPid);
	}
	else if (pidOut) {
		*pidOut = spawnedPid;
	}
	return 0;
}

int exec_cmd(const char *binary, ...)
{
	int argc = 1;
	va_list args;
	va_start(args, binary);
	while (va_arg(args, const char *)) argc++;
	va_end(args);

	va_start(args, binary);
	int r = __exec_cmd_internal_va(false, false, true, NULL, binary, argc, args, NULL);
	va_end(args);
	return r;
}

int exec_cmd_nowait(pid_t *pidOut, const char *binary, ...)
{
	int argc = 1;
	va_list args;
	va_start(args, binary);
	while (va_arg(args, const char *)) argc++;
	va_end(args);

	va_start(args, binary);
	int r = __exec_cmd_internal_va(false, false, false, pidOut, binary, argc, args, NULL);
	va_end(args);
	return r;
}

int exec_cmd_suspended(pid_t *pidOut, const char *binary, ...)
{
	int argc = 1;
	va_list args;
	va_start(args, binary);
	while (va_arg(args, const char *)) argc++;
	va_end(args);

	va_start(args, binary);
	int r = __exec_cmd_internal_va(true, false, false, pidOut, binary, argc, args, NULL);
	va_end(args);
	return r;
}

int exec_cmd_root(const char *binary, ...)
{
	int argc = 1;
	va_list args;
	va_start(args, binary);
	while (va_arg(args, const char *)) argc++;
	va_end(args);

	va_start(args, binary);
	int r = __exec_cmd_internal_va(false, true, true, NULL, binary, argc, args, NULL);
	va_end(args);
	return r;
}

int exec_cmd_env(char **envp, const char *binary, ...)
{
	int argc = 1;
	va_list args;
	va_start(args, binary);
	while (va_arg(args, const char *)) argc++;
	va_end(args);

	va_start(args, binary);
	int r = __exec_cmd_internal_va(false, false, true, NULL, binary, argc, args, envp);
	va_end(args);
	return r;
}

int jbctl_earlyboot(mach_port_t earlyBootServer, ...)
{
	int argc = 2;
	va_list args;
	va_start(args, earlyBootServer);
	while (va_arg(args, const char *)) argc++;
	va_end(args);

	const char *jbctlPath = JBROOT_PATH("/basebin/jbctl");
	const char *argsArr[argc+1];
	argsArr[0] = jbctlPath;
	va_start(args, earlyBootServer);
	for (int i = 1; i < argc-1; i++) {
		argsArr[i] = va_arg(args, const char *);
	}
	argsArr[argc-1] = "earlyboot";
	argsArr[argc] = NULL;

	posix_spawnattr_t attr;
	posix_spawnattr_init(&attr);
	posix_spawnattr_set_registered_ports_np(&attr, (mach_port_t[]){earlyBootServer, MACH_PORT_NULL, MACH_PORT_NULL}, 3);
	pid_t spawnedPid = 0;
	int r = posix_spawn(&spawnedPid, jbctlPath, NULL, &attr, (char *const *)argsArr, NULL);
	posix_spawnattr_destroy(&attr);
	if (r != 0) return r;
	return cmd_wait_for_exit(spawnedPid);
}

void walk_backtrace(bool (^block)(int frame_index, unw_word_t pc, unw_word_t offset, const char *symbol_name))
{
	unw_cursor_t cursor;
	unw_context_t context;

	unw_getcontext(&context);
	unw_init_local(&cursor, &context);

	int frame_index = 0;

	while (unw_step(&cursor) > 0) {
		unw_word_t offset, pc;
		unw_get_reg(&cursor, UNW_REG_IP, &pc);
		if (pc == 0) break;

		char sym[256];
		if (unw_get_proc_name(&cursor, sym, sizeof(sym), &offset) != 0) {
			sym[0] = '\0';
			offset = 0;
		}

		if (!block(frame_index, pc, offset, sym)) {
			break;
		}

		frame_index++;
	}
}

void proc_ucred_update(uint64_t proc, uint64_t newUcred)
{
	if (gSystemInfo.kernelStruct.proc_ro.exists) {
		uint64_t proc_ro = kread_ptr(proc + koffsetof(proc, proc_ro));
		kwrite64(proc_ro + koffsetof(proc_ro, ucred), newUcred);
	}
	else {
		kwrite_ptr(proc + koffsetof(proc, ucred), newUcred, 0x84E8);
	}
}

// NOTE: This functions assumes both processes to be in a somewhat paused state
// Right now, in practice this is
// procCopyTo: dyldhook or systemhook checking in (paused, waiting for response from launchd)
// procCopyFrom: child process of target binary spawned as root (paused, waiting for us to kill it)
void proc_copy_ucred(uint64_t procCopyFrom, uint64_t procCopyTo)
{
	uint64_t ucredToCopy = proc_ucred(procCopyFrom);
	uint64_t origUcred   = proc_ucred(procCopyTo);

	// Every process and every thread holds a lock on both ucred and ucred_rw

	// Since we replace the ucred of procCopyTo, we need to decrement the refcnt of it's original ucred
	// Then it will be freed by the system as soon as all threads have switched 
	// to the new ucred via current_cached_proc_cred_update
	kauth_cred_drop(origUcred);
	kauth_cred_unref(origUcred);

	// Since ucredToCopy will now be active on a new process, we need to bump it's refcount
	kauth_cred_ref(ucredToCopy);
	kauth_cred_hold(ucredToCopy);

	// TODO: do we need to preserve mac_label to retain entitlements?

	proc_ucred_update(procCopyTo, ucredToCopy);
}

int target_proc_with_ucred(const char *procPath, uid_t uid, gid_t gid, uid_t ruid, gid_t rgid, gid_t groups[NGROUPS_MAX])
{
	int comPipe[2];
	pipe(comPipe);

	posix_spawn_file_actions_t act;
	posix_spawn_file_actions_init(&act);
	posix_spawn_file_actions_adddup2(&act, comPipe[1], 3);

	char uidString[12];
	snprintf(uidString, sizeof(uidString), "%d", uid);

	char gidString[12];
	snprintf(gidString, sizeof(gidString), "%d", gid);

	char ruidString[12];
	snprintf(ruidString, sizeof(ruidString), "%d", ruid);

	char rgidString[12];
	snprintf(rgidString, sizeof(rgidString), "%d", rgid);

	char groupsStrings[NGROUPS_MAX][12];
	for (int i = 0; i < NGROUPS_MAX; i++) {
		snprintf(groupsStrings[i], sizeof(groupsStrings[i]), "%d", groups[i]);
	}

	// exec_path
	// 6 options
	// 5 options with one arg
	// 1 option with NGROUPS_MAX args
	// NULL
	const char *argv[1 + 6 + (5 * 1) + (1 * NGROUPS_MAX) + 1];
	int idx = 0;
	argv[idx++] = procPath;
	argv[idx++] = "--fd";
	argv[idx++] = "3";
	argv[idx++] = "--uid";
	argv[idx++] = uidString;
	argv[idx++] = "--ruid";
	argv[idx++] = ruidString;
	argv[idx++] = "--gid";
	argv[idx++] = gidString;
	argv[idx++] = "--rgid";
	argv[idx++] = rgidString;
	argv[idx++] = "--groups";
	for (int i = 0; i < NGROUPS_MAX; i++) {
		argv[idx++] = groupsStrings[i];
	}
	argv[idx++] = NULL;

	// In order to speed things up, skip any injection into the child process we spawn
	const char *envp[] = {
		"_SafeMode=1",
		"DYLD_HOOK_SETUID=1",
		NULL,
	};

	pid_t pid = 0;
	int r = posix_spawn(&pid, procPath, &act, NULL, (char *const *)argv, (char *const *)envp);
	posix_spawn_file_actions_destroy(&act);
	if (r == 0) {
		int r = 0;
		read(comPipe[0], &r, sizeof(r));
		close(comPipe[0]);
		close(comPipe[1]);
		return pid;
	}

	close(comPipe[0]);
	close(comPipe[1]);

	return -1;
}

int proc_ucred_update_content(uint64_t proc, const char *procPath, uid_t uid, gid_t gid, uid_t ruid, gid_t rgid, gid_t groups[NGROUPS_MAX])
{
	if (__builtin_available(iOS 17.0, *)) {
		int childPid = target_proc_with_ucred(procPath, uid, gid, ruid, rgid, groups);
		if (childPid == -1) {
			return -1;
		}

		uint64_t childProc = proc_find(childPid);
		proc_copy_ucred(childProc, proc);

		kill(childPid, SIGKILL);
		cmd_wait_for_exit(childPid);
	}
	else {
		uint64_t ucred = proc_ucred(proc);

		kwrite32(ucred + koffsetof(ucred, svuid), uid);
		kwrite32(ucred + koffsetof(ucred, uid), uid);

		kwrite32(ucred + koffsetof(ucred, svgid), gid);
		kwrite32(ucred + koffsetof(ucred, groups), gid);
	}

	if (gSystemInfo.kernelStruct.proc_ro.exists) {
		uint64_t proc_ro = kread_ptr(proc + koffsetof(proc, proc_ro));

		if (koffsetof(proc_ro, task_tokens)) {
			uint64_t auditToken = proc_ro + koffsetof(proc_ro, task_tokens) + koffsetof(task_token_ro_data, audit_token);
			kwrite32(auditToken + 4, uid); // uid
			kwrite32(auditToken + 8, gid); // gid
			kwrite32(auditToken + 12, ruid); // ruid
			kwrite32(auditToken + 16, rgid); // rgid
		}
	}

	return 0;
}

uint64_t vm_page_for_pnum(uint64_t pnum)
{
	uint64_t vm_pages = kread64(ksymbol(vm_page_array_beginning_addr));
	uint64_t vm_pages_end = kread64(ksymbol(vm_page_array_ending_addr));
	uint32_t vm_pages_first_pnum = kread64(ksymbol(vm_first_phys_ppnum));
	uint64_t vm_pages_count = (vm_pages_end - vm_pages) / ksizeof(vm_page);

	uint64_t page = 0;
	if (pnum >= (vm_pages_count + vm_pages_first_pnum))
	{
		page = 0;
	}
	else if (pnum >= vm_pages_first_pnum)
	{
		page = vm_pages + ((pnum - vm_pages_first_pnum) * ksizeof(vm_page));
	}
	else if (__builtin_available(iOS 27.0, *)) // pnum < vm_pages_first_pnum
	{
		// New path in iOS 27.0+ for pages between pmap_first_pnum and vm_pages_first_pnum
		// Actually not a new path, but we have no need for supporting this API on lower versions at the moment
		if (ksymbol(vm_pages_radix_root)) {
			page = vm_page_find_canonical_radix(pnum);
		}
	}

	return page;
}

uint64_t vm_page_for_pai(uint64_t pai)
{
	uint64_t vm_first_phys = kread64(ksymbol(vm_first_phys));
	return vm_page_for_pnum(pai + atop(vm_first_phys));
}

uint64_t vm_page_for_pa(uint64_t pa)
{
	return vm_page_for_pnum(atop(pa));
}

void killall(const char *executablePath, int signal)
{
	static int maxArgumentSize = 0;
	if (maxArgumentSize == 0) {
		size_t size = sizeof(maxArgumentSize);
		if (sysctl((int[]){ CTL_KERN, KERN_ARGMAX }, 2, &maxArgumentSize, &size, NULL, 0) == -1) {
			perror("sysctl argument size");
			maxArgumentSize = 4096; // Default
		}
	}
	int mib[3] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL};
	struct kinfo_proc *info;
	size_t length;
	int count;
	
	if (sysctl(mib, 3, NULL, &length, NULL, 0) < 0)
		return;
	if (!(info = malloc(length)))
		return;
	if (sysctl(mib, 3, info, &length, NULL, 0) < 0) {
		free(info);
		return;
	}
	count = length / sizeof(struct kinfo_proc);
	for (int i = 0; i < count; i++) {
		pid_t pid = info[i].kp_proc.p_pid;
		if (pid == 0) {
			continue;
		}
		size_t size = maxArgumentSize;
		char* buffer = (char *)malloc(length);
		if (sysctl((int[]){ CTL_KERN, KERN_PROCARGS2, pid }, 3, buffer, &size, NULL, 0) == 0) {
			char *cExecutablePath = buffer + sizeof(int);
			if (strcmp(cExecutablePath, executablePath) == 0) {
				kill(pid, signal);
			}
		}
		free(buffer);
	}
	free(info);
}

static int
copy_data(struct archive *ar, struct archive *aw)
{
	int r;
	const void *buff;
	size_t size;
	la_int64_t offset;

	for (;;) {
		r = archive_read_data_block(ar, &buff, &size, &offset);
		if (r == ARCHIVE_EOF)
			return (ARCHIVE_OK);
		if (r < ARCHIVE_OK)
			return (r);
		r = archive_write_data_block(aw, buff, size, offset);
		if (r < ARCHIVE_OK) {
			fprintf(stderr, "%s\n", archive_error_string(aw));
			return (r);
		}
	}
}

int libarchive_unarchive(const char *fileToExtract, const char *extractionPath)
{
	struct archive *a;
	struct archive *ext;
	struct archive_entry *entry;
	int flags;
	int r;

	/* Select which attributes we want to restore. */
	flags = ARCHIVE_EXTRACT_TIME;
	flags |= ARCHIVE_EXTRACT_PERM;
	flags |= ARCHIVE_EXTRACT_ACL;
	flags |= ARCHIVE_EXTRACT_FFLAGS;
	flags |= ARCHIVE_EXTRACT_OWNER;

	a = archive_read_new();
	archive_read_support_format_all(a);
	archive_read_support_filter_all(a);
	ext = archive_write_disk_new();
	archive_write_disk_set_options(ext, flags);
	archive_write_disk_set_standard_lookup(ext);
	if ((r = archive_read_open_filename(a, fileToExtract, 10240)))
			return 1;
	for (;;) {
			r = archive_read_next_header(a, &entry);
			if (r == ARCHIVE_EOF)
					break;
			if (r < ARCHIVE_OK)
					fprintf(stderr, "%s\n", archive_error_string(a));
			if (r < ARCHIVE_WARN)
					return 1;

			const char *currentFile = archive_entry_pathname(entry);
			char outputPath[PATH_MAX];
			strlcpy(outputPath, extractionPath, PATH_MAX);
			strlcat(outputPath, "/", PATH_MAX);
			strlcat(outputPath, currentFile, PATH_MAX);

			archive_entry_set_pathname(entry, outputPath);
			
			r = archive_write_header(ext, entry);
			if (r < ARCHIVE_OK)
					fprintf(stderr, "%s\n", archive_error_string(ext));
			else if (archive_entry_size(entry) > 0) {
					r = copy_data(a, ext);
					if (r < ARCHIVE_OK)
							fprintf(stderr, "%s\n", archive_error_string(ext));
					if (r < ARCHIVE_WARN)
							return 1;
			}
			r = archive_write_finish_entry(ext);
			if (r < ARCHIVE_OK)
					fprintf(stderr, "%s\n", archive_error_string(ext));
			if (r < ARCHIVE_WARN)
					return 1;
	}
	archive_read_close(a);
	archive_read_free(a);
	archive_write_close(ext);
	archive_write_free(ext);
	
	return 0;
}


// code from ktrw by Brandon Azad : https://github.com/googleprojectzero/ktrw
// A worker thread for activity_thread that just spins.
static void* worker_thread(void *arg)
{
	uint64_t end = *(uint64_t *)arg;
	for (;;) {
		close(-1);
		uint64_t now = mach_absolute_time();
		if (now >= end) {
			break;
		}
	}
	return NULL;
}

// A thread to alternately spin and sleep.
#define ACTIVITY_WORKER_COUNT 10
static void* activity_thread(void *arg)
{
	volatile uint64_t *runCount = arg;
	struct mach_timebase_info tb;
	mach_timebase_info(&tb);
	const unsigned milliseconds = 40;
	while (*runCount != 0) {
		// Spin for one period on multiple threads.
		uint64_t start = mach_absolute_time();
		uint64_t end = start + milliseconds * 1000 * 1000 * tb.denom / tb.numer;
		pthread_t worker[ACTIVITY_WORKER_COUNT];
		for (unsigned i = 0; i < ACTIVITY_WORKER_COUNT; i++) {
			pthread_create(&worker[i], NULL, worker_thread, &end);
		}
		worker_thread(&end);
		for (unsigned i = 0; i < ACTIVITY_WORKER_COUNT; i++) {
			pthread_join(worker[i], NULL);
		}
		// Sleep for one period.
		usleep(milliseconds * 1000);
	}
	return NULL;
}

static uint64_t gCaffeinateThreadRunCount = 0;
static pthread_t gCaffeinateThread = NULL;

void thread_caffeinate_start(void)
{
	if (gCaffeinateThreadRunCount == UINT64_MAX) return;
	gCaffeinateThreadRunCount++;
	if (gCaffeinateThreadRunCount == 1) {
		pthread_create(&gCaffeinateThread, NULL, activity_thread, &gCaffeinateThreadRunCount);
	}
}

void thread_caffeinate_stop(void)
{
	if (gCaffeinateThreadRunCount == 0) return;
	gCaffeinateThreadRunCount--;
	if (gCaffeinateThreadRunCount == 0) {
		pthread_join(gCaffeinateThread, NULL);
	}
}

void convert_data_to_hex_string(const void *data, size_t size, char *outBuf)
{
	unsigned char *pin = (unsigned char *)data;
	const char *hex = "0123456789ABCDEF";
	char *pout = outBuf;
	for(; pin < ((unsigned char *)data)+size; pout+=2, pin++){
		pout[0] = hex[(*pin>>4) & 0xF];
		pout[1] = hex[ *pin     & 0xF];
	}
	pout[0] = 0;
}

int convert_hex_string_to_data(const char *string, void *outBuf)
{
	size_t length = strlen(string);
	const char *pin = string;
	char *pout = outBuf;
	for (; pin < string+length; pin++) {
		char byte = *pin;
		if (byte >= '0' && byte <= '9') byte = byte - '0';
		else if (byte >= 'a' && byte <='f') byte = byte - 'a' + 10;
		else if (byte >= 'A' && byte <='F') byte = byte - 'A' + 10;
		else return -1;

		int shift = ((pin - (string+length)) % 2) ? 0 : 4;
		*pout = (*pout & ~(0xf << shift)) | (byte << shift);
		if (shift == 0) pout++;
	}
	return 0;
}

char *boot_manifest_hash(void)
{
	static char *gBuf = NULL;
	
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		io_registry_entry_t registryEntry = IORegistryEntryFromPath(kIOMainPortDefault, "IODeviceTree:/chosen");
		if (registryEntry) {
			CFDataRef bootManifestHashData = IORegistryEntryCreateCFProperty(registryEntry, CFSTR("boot-manifest-hash"), NULL, 0);
			CFIndex bootManifestHashLength = CFDataGetLength(bootManifestHashData);

			gBuf = malloc((bootManifestHashLength * 2 * sizeof(char)) + sizeof(char));
			unsigned char *buf = (unsigned char *)CFDataGetBytePtr(bootManifestHashData);
			convert_data_to_hex_string(buf, bootManifestHashLength, gBuf);

			CFRelease(bootManifestHashData);
		}
	});

	return gBuf;
}